/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kompresjahuffmana;

/**
 *
 * @author Daniel
 */
public class KompresjaHuffmana {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    
        System.out.println("\nAutor : DANIEL ZALEWSKI\n"); 
        
//tekst oryginalny do przeksztalcenia    
    String tekstDoK = "ABRACADABRAyyyygsrggesegsegseg!";
    System.out.println("\nTekst do kompresji " + tekstDoK);
    
//dlugosc ciagu
        int stringL = tekstDoK.length();
        System.out.println("\nLiczba znakow tekstu oryginalnego " + stringL);
//generowanie slownika 
       String slownik = MetodyPomocnicze.generowanieSlownika(tekstDoK);
       System.out.println("\nWygeneroany Slownik " + MetodyPomocnicze.generowanieSlownika(tekstDoK));        
        
//liczenie ilosci ruznych znakow
        int iloscZnakow = MetodyPomocnicze.generowanieSlownika(tekstDoK).length();
        System.out.println("\nIlosc roznych znakow " + iloscZnakow);
        
        
//rzutowanie dlugosci slownika
        String a = "" +(char)iloscZnakow;
        System.out.println("\nWynik rzutowania dlugosci slownika "+a +"\n");
        
        
        
//Tworzenie slownika/drzewa
         MetodyPomocnicze.tworzenieDrzewa(iloscZnakow,slownik);

            char[]slownikTab = new char[iloscZnakow];
            String[]wartosciTab = new String[iloscZnakow];
         
            slownikTab = MetodyPomocnicze.slownik;
            wartosciTab = MetodyPomocnicze.wartosci;
    
        for (int i = 0; i < iloscZnakow; i++) {
            
            System.out.println("znak ze slownika " + slownikTab[i] + " wartosc " + wartosciTab[i]);
            
        }
    
        
        
//Oblczanie ile bitow niezbedne jest na maske   
        int liczbabituwN = MetodyPomocnicze.liczenieMaski(MetodyPomocnicze.iloscBitowDoLiczeniaMaski);
        System.out.println("\nLiczba bitow potrzebnych do maski " + liczbabituwN);
        
//Liczenie reszty bitowej
        
        int resztaR = ((8-((stringL*liczbabituwN) + 3)%8)%8);
        System.out.println("\nReszta bitowa "+resztaR);
    
        
//przeksztalcenie bin na dzies
       
       System.out.println("\nPrzeksztalcenie liczb bin na dzies");
       System.out.println("Sprawdzenie czy dziala");
       String liczbaBin ="11111110";
       int liczbaDecZBin = MetodyPomocnicze.bin2Dec(liczbaBin);
       System.out.println("Liczba do przelozenia "+ liczbaBin);
       System.out.println("Liczba przelozona "+liczbaDecZBin+"\n");
       

       
//przeksztalcenie   dzies na bin
       int dec = 3;
       String bin = MetodyPomocnicze.dec2Bin(dec,liczbabituwN);
       System.out.println("\nPrzeksztalcenie dzies na bin");
       System.out.println("Sprawdzenie czy dziala ");
       System.out.println("Liczba do przelozenia "+ dec);
       System.out.println("Liczba przelozona "+bin+"\n");
       
//3 bity R
       
       String liczbaRNaString = MetodyPomocnicze.dec2Bin(resztaR,liczbabituwN);
//       System.out.println("liczba R " + resztaR);
//       System.out.println("liczba na string " + liczbaRNaString);
       
       int startIndex = liczbaRNaString.length() -3;
       int endIndex = liczbaRNaString.length();
       String pierwszeBityR = liczbaRNaString.substring(startIndex, endIndex);
       System.out.println("\nPierwsze 3 bity z liczby R " + pierwszeBityR);

//Tworzenie ciagu

    String ciagChar = MetodyPomocnicze.tworzenieCiagu(tekstDoK, pierwszeBityR,liczbabituwN,resztaR);
        System.out.println("\nWygenerowany ciag char'ow \npowstaly w wyniku kompresji " + ciagChar);




    }
    
}
