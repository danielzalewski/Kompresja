/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kompresjahuffmana;

import java.util.ArrayList;

/**
 *
 * @author Daniel
 */
public class MetodyPomocnicze {

    static char[] slownik;
    static String[] wartosci;
    static int iloscBitowDoLiczeniaMaski;

    MetodyPomocnicze(int dlugoscSlownika, char[] ciagSlownik, String[] wartosci) {

        this.slownik = new char[dlugoscSlownika];
        this.wartosci = new String[dlugoscSlownika];

        this.slownik = ciagSlownik;
        this.wartosci = wartosci;
    }

    static String sortowanie(String doPosortowania) {

        int[] tab = new int[doPosortowania.length()];

        for (int i = 0; i < tab.length; i++) {
            int liczbaZChar = (int) (doPosortowania.charAt(i));
            tab[i] = liczbaZChar;

        }

        //int[] tab = {5,100, 3, 18, 33, 2, 0, 11, 8, 9, 1};
        int[] tabUporzadkowana = new int[tab.length];

        int max = tab[0];
        int k = 0;

        for (int i = k; i < tab.length; i++) {

            for (int y = k; y < tab.length; y++) {
                //System.out.println("pentla max i " + i + " y "+ y);
                if (tab[y] > max) {
                    max = tab[y];

                    int tabI = tab[i];
                    int tabY = tab[y];

                    tab[y] = tabI;
                    tab[i] = tabY;
                }

            }

            tabUporzadkowana[i] = max;
            max = 0;
            k++;
            //tab[k]=max;
        }

//         for(int x : tab)
//        {
//            System.out.println("wartosc tab NIE uporzadkowanej " + x);
//        }    
//        for (int x : tabUporzadkowana) {
//            System.out.println("wartosc tab uporzadkowanej " + x);
//        }
        String posortowany = "";

        for (int i = (doPosortowania.length() - 1); i >= 0; i--) {

            char znak = (char) tabUporzadkowana[i];
            posortowany = posortowany + znak;

        }

        //System.out.println("POSORTOWANY STRING " + posortowany);
        return posortowany;
    }

    static String generowanieSlownika(String ciag) {

        ArrayList<Character> ciagZnakow = new ArrayList<>();

        for (int i = 0; i < ciag.length(); i++) {

            ciagZnakow.add(ciag.charAt(i));

        }

        for (int i = 0; i < ciagZnakow.size(); i++) {

            for (int j = i; j < ciagZnakow.size(); j++) {

                if (j == i) {
                    continue;
                }
                if (ciagZnakow.get(i) == ciagZnakow.get(j)) {

                    
                    ciagZnakow.remove(j);

                }

            }

        }

        String slownik = "";

        for (int i = 0; i < ciagZnakow.size(); i++) {

            slownik = slownik + ciagZnakow.get(i);

        }

        //System.out.println("Slownik " + slownik);
//        for (Character character : ciagZnakow) {
//
//            System.out.println("char " + character);
//        }
        String posortowanySlownik = sortowanie(slownik);

        return posortowanySlownik;
    }

    static int potegowanieLiczb(int liczba, int potenga) {

        int wynik = 1;
        if (potenga == 0) {
            wynik = 1;
        } else if (potenga == 1) {
            wynik = liczba;
        } else {

            int i = 1;

            while (i <= potenga) {

                wynik = liczba * wynik;
                i++;
            }
        }

        return wynik;
    }

    static int obliczanieIlosciZnakow(int iloscZnakow) {

        //System.out.println("Log ^a b = c   a^c = b ");
        int iloscBitow = potegowanieLiczb(2, iloscZnakow);

        return iloscBitow;

    }

    static void tworzenieDrzewa(int dlugoscSlownika, String slownik) {

//        ArrayList<Character> ciagSlownik = new ArrayList<>();
//        ArrayList<String> wartosci  = new ArrayList<>();
        char[] ciagSlownik = new char[dlugoscSlownika];
        String[] wartosci = new String[dlugoscSlownika];

//        System.out.println("DLUGOSC SLOWNIKA " + dlugoscSlownika);
//        System.out.println("SLOWNIK " + slownik);
        for (int i = 0; i < dlugoscSlownika; i++) {

            //ciagSlownik.add(slownik.charAt(i));
            ciagSlownik[i] = slownik.charAt(i);

        }

//        for (char string : ciagSlownik) {
//            System.out.println(string);
//        }
        int x = dlugoscSlownika;
        int prawaStrona = 0;

        if (x % 2 == 0) {

            prawaStrona = x / 2;
            //  System.out.println("prawa  modul0 0= " + prawaStrona);
        } else {

            prawaStrona = x / 2 + 1;
            // System.out.println("prawa  +1 = " + prawaStrona);
        }

        int lewaStrona = x - prawaStrona;

        String prawy = "";
        String lewy = "";
        int index = 0;

        while (prawaStrona != 0) {

            if (prawaStrona == 1) {

                prawy = prawy + "1";
                //wartosci.add(prawy);
                wartosci[index] = prawy;
                //System.out.println("zapis");
                index++;
                prawaStrona--;

            } else {
                prawy = prawy + "1";
                lewy = prawy + "0";
                //wartosci.add(lewy);
                wartosci[index] = lewy;
                // System.out.println("zapis"); 
                prawaStrona--;
                index++;

            }

        }

        prawy = "";
        lewy = "";

        while (lewaStrona != 0) {

            if (lewaStrona == 1) {

                lewy = lewy + "0";
                //wartosci.add(prawy);
                wartosci[index] = lewy;
                //System.out.println("zapis");
                index++;
                lewaStrona--;

            } else {
                lewy = lewy + "0";
                prawy = lewy + "1";
                //wartosci.add(lewy);
                wartosci[index] = prawy;
                // System.out.println("zapis"); 
                lewaStrona--;
                index++;

            }

        }
//
//        for (String string : wartosci) {
//            System.out.println(string);
//        }

        MetodyPomocnicze drzewo = new MetodyPomocnicze(dlugoscSlownika, ciagSlownik, wartosci);
        obliczanieBituwSlownika(wartosci);
    }

    static void obliczanieBituwSlownika(String[] wartosciSlownik) {

        int suma = 0;
        for (int i = 0; i < wartosciSlownik.length; i++) {

            int liczba = wartosciSlownik[i].length();
            suma = suma + liczba;
        }

        iloscBitowDoLiczeniaMaski = suma;
    }

    static int liczenieMaski(int sumaBitow) {

        sumaBitow = sumaBitow;
        int bityNaMaske = 0;
        int x = 0;
        int potengaC = 0;

        //System.out.println("SUMA BITOW DO LICZENIA MASKI " + sumaBitow);
        while (x < sumaBitow) {

            if (x == 0) {
                x = 1;
            } else if (x == 1) {
                x = 2;
            } else {

                x = x * 2;
            }

            bityNaMaske++;
            //System.out.println("test x= " + x);
        }

        if (x > sumaBitow) {
            bityNaMaske = bityNaMaske - 1;
        }

        return bityNaMaske;
    }

    static int bin2Dec(String bin) {

        int dec = 0;
        int wartoscBramki = 1;

        for (int i = (bin.length() - 1); i >= 0; i--) {
            char liczbaBin = bin.charAt(i);
            if (liczbaBin == '1') {

                dec = dec + wartoscBramki;
                wartoscBramki = wartoscBramki * 2;

            } else {

                wartoscBramki = wartoscBramki * 2;

            }

        }

        return dec;
    }

    static String dec2Bin(int dec, int iloscBituwMaski) {

        String bin = "";

//        System.out.println("dec " + dec);
//        System.out.println("ilosc bituw " + iloscBituwMaski);
        int pom = 1;
        int max = 0;

        for (int i = 0; i < iloscBituwMaski; i++) {

            if (i == 0) {
                pom = 1;
            } else {
                pom = pom * 2;
            }
            max = max + pom;
        }

        //System.out.println("max " + max);
        if (dec > max) {

            System.out.println("Podano za duza liczbe do pzetworzenia");
            System.out.println("Maska ma ograniczona dlugosc");
        } else {

            int bramka = 1;
            for (int i = 1; i < iloscBituwMaski; i++) {

                bramka = bramka * 2;

            }

            //System.out.println("bramka " + bramka);
            for (int i = 0; i < iloscBituwMaski; i++) {

                if (dec >= bramka) {

                    bin = bin + "1";
                    dec = dec - bramka;
                    bramka = bramka / 2;
                } else {

                    bin = bin + "0";
                    bramka = bramka / 2;
                }

            }

        }

        //System.out.println("BINNN " + bin);
        return bin;
    }

    static String tworzenieCiagu(String tekstOryginalny, String pierwsze3BityR, int liczbaBituwMaski, int resztaR) {
        //00111011 100011001110

        String[] wartoscii = MetodyPomocnicze.wartosci;
        char[] slownikk = MetodyPomocnicze.slownik;

//Przeksztalcanie tabeli wartosci(liczby do postaci maski
        int[] wartosciToint = new int[wartoscii.length];

        for (int i = 0; i < wartoscii.length; i++) {

            wartosciToint[i] = bin2Dec(wartoscii[i]);

        }

        String[] wartosciPrzeksztalcone = new String[wartoscii.length];

        for (int i = 0; i < wartoscii.length; i++) {

            wartosciPrzeksztalcone[i] = dec2Bin(wartosciToint[i], liczbaBituwMaski);

        }

        String ciag = pierwsze3BityR;
        String wyciete8Bituw = "";
        String null2 = "";
        String ciagCharZ8 = "";

        String stringSprawdzajacy = "";

        for (int j = 0; j < tekstOryginalny.length(); j++) {
            char znak = tekstOryginalny.charAt(j);
            if (ciag.length() >= 8) {
                wyciete8Bituw = ciag.substring(0, 8);
                ciag = ciag.substring(8);

                int pierwsze8Toint = bin2Dec(wyciete8Bituw);
                char znakZ8 = (char) pierwsze8Toint;
                ciagCharZ8 = ciagCharZ8 + znakZ8;
            }

            for (int i = 0; i < wartosciPrzeksztalcone.length; i++) {

                char znakSlownik = slownikk[i];

                if (znak == znakSlownik) {
                    stringSprawdzajacy = stringSprawdzajacy + znak;
                    String wartosc = wartosciPrzeksztalcone[i];
                    //System.out.println("if wartosc[i] " + wartosc);
                    ciag = ciag + wartosc;

                }

            }
        }

//        System.out.println("ciag " + ciag);
//        System.out.println("ciag char " + ciagCharZ8);

        if (ciag.length() < 8 && ciag.length() != 0) {

            for (int i = 0; i < resztaR; i++) {
                ciag = ciag + "1";
                //System.out.println("CIAGGGGG " + ciag);
            }
            wyciete8Bituw = ciag;
            int pierwsze8Toint = bin2Dec(wyciete8Bituw);
            char znakZ8 = (char) pierwsze8Toint;
            ciagCharZ8 = ciagCharZ8 + znakZ8;

        }

        // System.out.println("pierwsze 8 " + wyciete8Bituw);
        // System.out.println("ciag char " + ciagCharZ8);
//         System.out.println("String sprawdzajacy " + stringSprawdzajacy);
//         
//         
//         for (String string : wartosciPrzeksztalcone) {
//             
//             System.out.println("wartosci z maska " + string);
//             
//         }
//         
//         for (String string : wartoscii) {
//             
//             System.out.println("wartosci BEZ maski " + string);
//             
//         }
//         
//         System.out.println("ilosc bitow do maski " + liczbaBituwMaski);
        return ciagCharZ8;

    }

}
